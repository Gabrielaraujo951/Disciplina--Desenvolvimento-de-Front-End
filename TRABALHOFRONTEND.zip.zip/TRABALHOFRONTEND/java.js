// --- CONTROLE DE ABAS ---
function mostrarAba(aba) {
  document.querySelectorAll(".aba").forEach(sec => {
    sec.classList.remove("ativa");
  });

  document.getElementById(aba).classList.add("ativa");
}

// --- TABELA (EXEMPLO DE TIMES) ---
const dadosTimes = [
  { pos: 1, time: "Palmeiras", pts: 38, j: 18, v: 12, e: 2, d: 4, gp: 30, gc: 12, sg: 18 },
  { pos: 2, time: "Flamengo", pts: 36, j: 18, v: 11, e: 3, d: 4, gp: 34, gc: 20, sg: 14 },
  { pos: 3, time: "Cruzeiro", pts: 32, j: 18, v: 10, e: 2, d: 6, gp: 28, gc: 19, sg: 9 }
];

function carregarTabela() {
  let corpo = document.getElementById("tabelaTimes");
  corpo.innerHTML = "";

  dadosTimes.forEach(t => {
    corpo.innerHTML += `
      <tr>
        <td>${t.pos}</td>
        <td>${t.time}</td>
        <td>${t.pts}</td>
        <td>${t.j}</td>
        <td>${t.v}</td>
        <td>${t.e}</td>
        <td>${t.d}</td>
        <td>${t.gp}</td>
        <td>${t.gc}</td>
        <td>${t.sg}</td>
      </tr>
    `;
  });
}

carregarTabela();

// --- CADASTRO ---
function validarFormulario() {
  let nome = document.getElementById("nome").value.trim();
  let email = document.getElementById("email").value.trim();
  let time = document.getElementById("time").value;

  if (nome === "" || email === "" || time === "") {
    alert("Preencha todos os campos!");
    return false;
  }

  document.getElementById("mensagemCadastro").innerHTML =
    `<p style="color: var(--accent);">Cadastro realizado com sucesso!</p>`;

  return false; // evita recarregar página
}

// --- MÉDIA ---
function calcularMedia() {
  let g1 = Number(document.getElementById("gol1").value);
  let g2 = Number(document.getElementById("gol2").value);
  let g3 = Number(document.getElementById("gol3").value);

  if (isNaN(g1) || isNaN(g2) || isNaN(g3)) {
    alert("Digite valores válidos!");
    return;
  }

  let media = (g1 + g2 + g3) / 3;

  document.getElementById("resultadoMedia").textContent =
    `Média de gols: ${media.toFixed(2)}`;
}
